JavaFF
======
An implementation of FF Planner in Java.

The initial commit for this repository was taken from the original source developed by Andrew Coles: http://www.inf.kcl.ac.uk/staff/andrew/JavaFF/. More information regarding the planner can be found on the JavaFF homepage.
